# server_tls.py
import socket, ssl

HOST = '0.0.0.0'
PORT = 9443
CERT = 'cert.pem'
KEY = 'key.pem'

context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain(certfile=CERT, keyfile=KEY)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as bindsock:
    bindsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    bindsock.bind((HOST, PORT))
    bindsock.listen(5)
    print(f"TLS server listening on {HOST}:{PORT}")
    while True:
        newsock, addr = bindsock.accept()
        print("Connection from", addr)
        try:
            with context.wrap_socket(newsock, server_side=True) as ssock:
                data = ssock.recv(4096)
                if data:
                    print("Received (server):", data.decode(errors='replace').rstrip())
                    ssock.sendall(b"ACK (TLS): " + data)
        except Exception as e:
            print("Connection error:", e)
