# client_plain.py
import socket, sys, time

if len(sys.argv) < 2:
    print("Usage: python client_plain.py SERVER_IP")
    sys.exit(1)

HOST = sys.argv[1]
PORT = 9000

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    for i in range(3):
        msg = f"Hello plaintext {i}\n".encode()
        s.sendall(msg)
        data = s.recv(4096)
        print('Received', data.decode(errors='replace').rstrip())
        time.sleep(0.5)
