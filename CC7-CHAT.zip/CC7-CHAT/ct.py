# client_tls.py
import socket, ssl, sys, time

if len(sys.argv) < 2:
    print("Usage: python client_tls.py SERVER_IP")
    sys.exit(1)

HOST = sys.argv[1]
PORT = 9443

context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
# skip verification for local self-signed cert
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE

with socket.create_connection((HOST, PORT)) as sock:
    with context.wrap_socket(sock, server_hostname=HOST) as ssock:
        for i in range(3):
            msg = f"Hello over TLS {i}\n".encode()
            ssock.sendall(msg)
            data = ssock.recv(4096)
            print("Client received:", data.decode(errors='replace').rstrip())
            time.sleep(0.5)
